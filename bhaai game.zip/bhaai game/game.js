const canvas = document.getElementById("canvas");
const laughAudio = new Audio("audio/laugh.mp3");
laughAudio.volume = 0.8;


const passAudio = new Audio("audio/pass.mp3");
passAudio.volume = 0.8;
const ctx = canvas.getContext("2d");

const message = document.getElementById("message");
const startButton = document.getElementById("startButton");
const scoreText = document.getElementById("score");

let width;
let height;
let gameRunning = false;
let score = 0;

const keys = {};

const player = {
    x: 100,
    y: 300,
    radius: 18,
    speed: 4
};

const paradise = {
    x: 0,
    y: 0,
    radius: 60
};

const villagers = [
    { x: 260, y: 180, radius: 27 },
    { x: 430, y: 400, radius: 27 },
    { x: 600, y: 220, radius: 27 },
    { x: 770, y: 450, radius: 27 },
    { x: 900, y: 250, radius: 27 }
];

const enemies = [
    { x: 350, y: 100, radius: 20, dx: 2, dy: 1.5 },
    { x: 700, y: 350, radius: 20, dx: -1.5, dy: 2 },
    { x: 850, y: 120, radius: 20, dx: 2, dy: -1.5 }
];

function resizeCanvas() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;

    paradise.x = width - 90;
    paradise.y = height / 2;
}

window.addEventListener("resize", resizeCanvas);
resizeCanvas();

document.addEventListener("keydown", function(event) {
    keys[event.key.toLowerCase()] = true;
});

document.addEventListener("keyup", function(event) {
    keys[event.key.toLowerCase()] = false;
});

startButton.addEventListener("click", startGame);

function startGame() {
    message.style.display = "none";

    player.x = 100;
    player.y = height / 2;

    score = 0;
    scoreText.textContent = "Score: 0";

    gameRunning = true;

    requestAnimationFrame(gameLoop);
}

function movePlayer() {

    if (keys["arrowup"] || keys["w"]) {
        player.y -= player.speed;
    }

    if (keys["arrowdown"] || keys["s"]) {
        player.y += player.speed;
    }

    if (keys["arrowleft"] || keys["a"]) {
        player.x -= player.speed;
    }

    if (keys["arrowright"] || keys["d"]) {
        player.x += player.speed;
    }

    player.x = Math.max(
        player.radius,
        Math.min(width - player.radius, player.x)
    );

    player.y = Math.max(
        player.radius,
        Math.min(height - player.radius, player.y)
    );
}

function moveEnemies() {

    enemies.forEach(enemy => {

        enemy.x += enemy.dx;
        enemy.y += enemy.dy;

        if (
            enemy.x < enemy.radius ||
            enemy.x > width - enemy.radius
        ) {
            enemy.dx *= -1;
        }

        if (
            enemy.y < enemy.radius ||
            enemy.y > height - enemy.radius
        ) {
            enemy.dy *= -1;
        }
    });
}

function distance(a, b) {
    return Math.hypot(
        a.x - b.x,
        a.y - b.y
    );
}

function checkVillagers() {

    villagers.forEach(villager => {

        if (
            distance(player, villager) <
            player.radius + villager.radius
        ) {

            score += 10;

            scoreText.textContent =
                "Score: " + score;

            passAudio.currentTime = 0;
            passAudio.play();

            player.x += 35;

            player.y +=
                (Math.random() - 0.5) * 60;
        }
    });
}

function checkEnemies() {

    enemies.forEach(enemy => {

        if (
            distance(player, enemy) <
            player.radius + enemy.radius
        ) {
            gameOver();
        }
    });
}

function checkParadise() {

    if (
        distance(player, paradise) <
        player.radius + paradise.radius
    ) {
        winGame();
    }
}

function drawBackground() {

    ctx.fillStyle = "#79c267";
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle =
        "rgba(255,255,255,0.15)";

    ctx.lineWidth = 2;

    for (let x = 0; x < width; x += 80) {

        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
    }

    for (let y = 0; y < height; y += 80) {

        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }
}

function drawParadise() {

    ctx.beginPath();

    ctx.arc(
        paradise.x,
        paradise.y,
        paradise.radius,
        0,
        Math.PI * 2
    );

    ctx.fillStyle = "#ffe066";
    ctx.fill();

    ctx.strokeStyle = "white";
    ctx.lineWidth = 5;
    ctx.stroke();

    ctx.fillStyle = "#222";
    ctx.font = "bold 15px Arial";
    ctx.textAlign = "center";

    ctx.fillText(
        "JAIL",
        paradise.x,
        paradise.y + 5
    );
}

function drawVillagers() {

    villagers.forEach(villager => {

        ctx.beginPath();

        ctx.arc(
            villager.x,
            villager.y,
            villager.radius,
            0,
            Math.PI * 2
        );

        ctx.fillStyle = "#4dabf7";
        ctx.fill();

        ctx.strokeStyle = "white";
        ctx.lineWidth = 3;
        ctx.stroke();

        ctx.fillStyle = "#222";

        ctx.beginPath();

        ctx.arc(
            villager.x - 8,
            villager.y - 4,
            3,
            0,
            Math.PI * 2
        );

        ctx.arc(
            villager.x + 8,
            villager.y - 4,
            3,
            0,
            Math.PI * 2
        );

        ctx.fill();
    });
}

function drawEnemies() {

    enemies.forEach(enemy => {

        ctx.beginPath();

        ctx.arc(
            enemy.x,
            enemy.y,
            enemy.radius,
            0,
            Math.PI * 2
        );

        ctx.fillStyle = "#ff5252";
        ctx.fill();

        ctx.fillStyle = "white";

        ctx.beginPath();

        ctx.arc(
            enemy.x - 6,
            enemy.y - 3,
            4,
            0,
            Math.PI * 2
        );

        ctx.arc(
            enemy.x + 6,
            enemy.y - 3,
            4,
            0,
            Math.PI * 2
        );

        ctx.fill();
    });
}

function drawPlayer() {

    ctx.beginPath();

    ctx.arc(
        player.x,
        player.y,
        player.radius,
        0,
        Math.PI * 2
    );

    ctx.fillStyle = "#ffd43b";
    ctx.fill();

    ctx.strokeStyle = "white";
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.fillStyle = "#222";

    ctx.beginPath();

    ctx.arc(
        player.x - 6,
        player.y - 3,
        3,
        0,
        Math.PI * 2
    );

    ctx.arc(
        player.x + 6,
        player.y - 3,
        3,
        0,
        Math.PI * 2
    );

    ctx.fill();
}

function update() {

    movePlayer();
    moveEnemies();

    checkVillagers();
    checkEnemies();
    checkParadise();
}

function draw() {

    drawBackground();
    drawParadise();
    drawVillagers();
    drawEnemies();
    drawPlayer();
}

function gameLoop() {

    if (!gameRunning) {
        return;
    }

    update();
    draw();

    requestAnimationFrame(gameLoop);
}

function gameOver() {

    gameRunning = false;

    message.innerHTML = `
        <h1>GAME OVER</h1>
        <p>You got caught!</p>
        <p>Score: ${score}</p>
        <button id="restartButton">
            TRY AGAIN
        </button>
    `;

    message.style.display = "flex";

    document
        .getElementById("restartButton")
        .addEventListener("click", startGame);
}

function winGame() {

    gameRunning = false;

    laughAudio.currentTime = 0;
    laughAudio.play();

    message.innerHTML = `
        <h1>YOU MADE IT!</h1>
        <p>Welcome to Paradise 😂</p>
        <p>Score: ${score}</p>
        <button id="restartButton">
            PLAY AGAIN
        </button>
    `;

    message.style.display = "flex";

    document
        .getElementById("restartButton")
        .addEventListener("click", startGame);
}